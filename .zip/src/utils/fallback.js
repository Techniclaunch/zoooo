export const fallback_1="megaplay.buzz"
export const fallback_2="vidwish.live"